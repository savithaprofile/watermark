
import { useEffect, useRef, useState } from 'react';
import { EventLogger } from '../services/EventLogger';

interface WatermarkProps {
  candidateName: string;
  candidateId: string;
  attemptId: string;
}

const Watermark: React.FC<WatermarkProps> = ({ candidateName, candidateId, attemptId }) => {
  const [timestamp, setTimestamp] = useState(new Date().toLocaleString());
  const containerRef = useRef<HTMLDivElement>(null);

  // Update timestamp every second
  useEffect(() => {
    const interval = setInterval(() => {
      setTimestamp(new Date().toLocaleString());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Initial log
  useEffect(() => {
    EventLogger.log('WATERMARK_RENDERED', { candidateId });
  }, [candidateId]);

  // Anti-tamper: MutationObserver
  useEffect(() => {
    const targetNode = containerRef.current?.parentElement || document.body;

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          // Check if our watermark was removed
          const removedNodes = Array.from(mutation.removedNodes);
          const isRemoved = removedNodes.some(node =>
            node === containerRef.current ||
            (node as HTMLElement).id === 'secure-watermark-container'
          );

          if (isRemoved) {
            EventLogger.log('WATERMARK_TAMPER_ATTEMPT', { method: 'DOM_REMOVAL' });
            // Force layout re-render or alert (In real app, we might restore it)
            alert('Watermark tampering detected! This incident has been logged.');
            window.location.reload(); // Aggressive measure for demo
          }
        } else if (mutation.type === 'attributes' && mutation.target === containerRef.current) {
          // Check for style/class changes hiding it
          const element = mutation.target as HTMLElement;
          const style = element.style;

          if (
            style.opacity === '0' ||
            style.display === 'none' ||
            style.visibility === 'hidden' ||
            style.zIndex !== '9999' ||
            style.position !== 'fixed'
          ) {
            EventLogger.log('WATERMARK_TAMPER_ATTEMPT', { method: 'STYLE_MANIPULATION' });
            // Restore styles
            style.opacity = '0.4';
            style.display = 'flex';
            style.visibility = 'visible';
            style.zIndex = '9999';
            style.position = 'fixed';
            style.width = '100vw';
            style.height = '100vh';
          }
        }
      });
    });

    if (containerRef.current) {
      observer.observe(document.body, { childList: true, subtree: true });
      observer.observe(containerRef.current, {
        attributes: true,
        attributeFilter: ['style', 'class', 'hidden']
      });
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      id="secure-watermark-container"
      ref={containerRef}
      aria-hidden="true"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        pointerEvents: 'none',
        zIndex: 9999,
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        alignItems: 'center',
        overflow: 'hidden',
        opacity: 0.4,
        mixBlendMode: 'difference', // Makes text visible on light/dark backgrounds
      }}
    >
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          style={{
            transform: 'rotate(-45deg)',
            margin: '50px',
            color: 'rgba(150, 150, 150, 0.5)',
            fontSize: '14px',
            fontFamily: 'monospace',
            userSelect: 'none',
          }}
        >
          <div>{candidateName} ({candidateId})</div>
          <div>{attemptId}</div>
          <div>{timestamp}</div>
        </div>
      ))}
    </div>
  );
};

export default Watermark;