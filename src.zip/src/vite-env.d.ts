
/// <reference types="vite/client" />
